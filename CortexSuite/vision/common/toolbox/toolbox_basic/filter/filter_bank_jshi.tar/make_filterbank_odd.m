M1=13;
M2=M1;
sig=1;
GD0=gaussder(0,M1,sig);
GD1=gaussder(1,M1,sig);
GD2=gaussder(2,M1,sig);

GD=cat(3,GD0,GD1,GD2);

FB=GD;
FB(:,:,5)=0.25*(FB(:,:,4)+2*FB(:,:,5)+FB(:,:,6));

total_num_filt=size(FB,3);

if 0
for n=1:total_num_filt
   FB(:,:,n)=FB(:,:,n)/sqrt(sum(sum(FB(:,:,n).^2)));
end
end

