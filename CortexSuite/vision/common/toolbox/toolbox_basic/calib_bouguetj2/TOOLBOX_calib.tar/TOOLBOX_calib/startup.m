% Main camera calibration toolbox:

calib_gui;

%calib_gui;

path(pwd,path);

format compact
