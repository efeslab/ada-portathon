function [x] = comp_distortion_oulu(xd,k);

% Function that compensates for radial and tangential distortion
% Model from Oulu university


if length(k) < 4,
   
   [x] = comp_distortion(xd,k);
   
else
   
   
   k1 = k(1);
   k2 = k(2);
   
   p1 = k(3);
   p2 = k(4);
   
   
   x = xd; 				% first guess
   
   for kk=1:5;
      
      r_2 = sum(x.^2);
      k_radial =  1 + k1 * r_2 + k2 * r_2.^2;
      delta_x = [2*p1*x(1,:).*x(2,:) + p2*(r_2 + 2*x(1,:).^2) ;
	    p1 * (r_2 + 2*x(2,:).^2)+2*p2*x(1,:).*x(2,:)];
      x = (xd - delta_x)./(ones(2,1)*k_radial);
      
   end;
   
end;

