
% enter image names, numbers, ...
data_calib;

%read images from files
ima_read_calib;

click_calib;

%go_calib; % the original version

go_calib_optim;
