*---------------------------------------------------------------------------------------*
|    Camera calibration toolbox from multiple images of a planar pattern (in Matlab)    |
|                        (c) Jean-Yves Bouguet - August 1999                            |
|                                                                                       |
|                       http://www.vision.caltech.edu/bouguetj                          |
*---------------------------------------------------------------------------------------*



GENERAL NOTICE: The Matlab Optimization toolbox is required to use that toolbox.



INSTRUCTIONS:

1- Run matlab under TOOLBOX_calib.
   Under Windows environment, add the calibration directory path
   to the main matlab path (to have access to all the functions).

2- To launch the main camera calibration toolbox run under Matlab:

   calib_gui;

   A list of instructions is also given.

3- Go to the directory that contains the calibration images, and
   follow the instructions.

   NOTE: The images must be in either format: ras, bmp or tif.
         The image file names must start with a common basename,
         followed by a number, and the file extension ('ras', 'bmp'
         or 'tif').

   Example: If 15 tif images are used for calibration, with basename
            'camera_calib', then the file names may be:

            camera_calib1.tif
            camera_calib2.tif
            camera_calib3.tif
            camera_calib4.tif
            camera_calib5.tif
            camera_calib6.tif
            camera_calib7.tif
            camera_calib8.tif
            camera_calib9.tif
            camera_calib10.tif
            camera_calib11.tif
            camera_calib12.tif
            camera_calib13.tif
            camera_calib14.tif
            camera_calib15.tif

            The first image number may be anything (1, 0 or anything else).
            Another numbering may be used if one chooses to reserve a fixed
            number of character spaces for the numbers. For example, if two
            fixed slots are reserved in the previous case, the file names
            become:

            camera_calib01.tif
            camera_calib02.tif
            camera_calib03.tif
            camera_calib04.tif
            camera_calib05.tif
            camera_calib06.tif
            camera_calib07.tif
            camera_calib08.tif
            camera_calib09.tif
            camera_calib10.tif
            camera_calib11.tif
            camera_calib12.tif
            camera_calib13.tif
            camera_calib14.tif
            camera_calib15.tif

            More slots may be used as well. For example, the following file
            names would still work:

            camera_calib0001.tif
            camera_calib0002.tif
            camera_calib0003.tif
            camera_calib0004.tif
            camera_calib0005.tif
            camera_calib0006.tif
            camera_calib0007.tif
            camera_calib0008.tif
            camera_calib0009.tif
            camera_calib0010.tif
            camera_calib0011.tif
            camera_calib0012.tif
            camera_calib0013.tif
            camera_calib0014.tif
            camera_calib0015.tif


4- The final calibration results (intrinsic and extrinsic) are saved under
   Calib_Results.mat



Send your questions to bouguetj@vision.caltech.edu
