
if ~exist('calib_name'),
   data_calib;
end;

image_numbers = first_num:n_ima-1+first_num;

for i = 1:n_ima,

   fprintf(1,'Loading image %d...\n',i);
   
   if ~type_numbering,   
      number_ext =  num2str(image_numbers(i));
   else
      number_ext = sprintf(['%.' num2str(N_slots) 'd'],image_numbers(i));
   end;

   if format_image(1) == 'r',   
      Ii = readras([calib_name  number_ext '.ras']);
   else
      Ii = double(imread([calib_name  number_ext '.' format_image]));
   end;
   
   
   if size(Ii,3)>1,
      Ii = Ii(:,:,2);
   end;
   
   
   eval(['I_' num2str(i) ' = Ii;']);
   
end;


if size(I_1,1)~=480,
   small_calib_image = 1;
else
   small_calib_image = 0;
end;
   

[Hcal,Wcal] = size(I_1); 	% size of the calibration image
   
clickname = [];

map = gray(256);

[ny,nx] = size(I_1);


%string_save = 'save calib_data n_ima type_numbering N_slots image_numbers format_image calib_name Hcal Wcal nx ny map small_calib_image';

%eval(string_save);

%disp('done');
click_calib;

