% Simplified version of go_calib.m


if ~exist('x_1'),
   click_calib;
end;


fprintf(1,'\nMain calibration procedure\n');

% initial guess for principal point and distortion:
c_init = [nx;ny]/2 - 0.5; % initialize at the center of the image
k_init = [0;0;0;0]; % initialize to zero (no distortion)


% Compute explicitely the focal lentgh using all the (mutually orthogonal) vanishing points
% note: The vanihing points are hidden in the planar collineations H_kk

A = [];
b = [];

% matrix that subtract the principal point:
Sub_cc = [1 0 -c_init(1);0 1 -c_init(2);0 0 1];

H_list = cell(1,n_ima);

for kk=1:n_ima,
   
   eval(['Hkk = H_' num2str(kk) ';']);
   
   Hkk = Sub_cc * Hkk;
      
   H_list{kk} = Hkk;
   
   % Extract vanishing points (direct and diagonals):
   
   V_hori_pix = Hkk(:,1);
   V_vert_pix = Hkk(:,2);
   V_diag1_pix = (Hkk(:,1)+Hkk(:,2))/2;
   V_diag2_pix = (Hkk(:,1)-Hkk(:,2))/2;
   
   V_hori_pix = V_hori_pix/norm(V_hori_pix);
   V_vert_pix = V_vert_pix/norm(V_vert_pix);
   V_diag1_pix = V_diag1_pix/norm(V_diag1_pix);
   V_diag2_pix = V_diag2_pix/norm(V_diag2_pix);
   
   a1 = V_hori_pix(1);
   b1 = V_hori_pix(2);
   c1 = V_hori_pix(3);
   
   a2 = V_vert_pix(1);
   b2 = V_vert_pix(2);
   c2 = V_vert_pix(3);
   
   a3 = V_diag1_pix(1);
   b3 = V_diag1_pix(2);
   c3 = V_diag1_pix(3);
   
   a4 = V_diag2_pix(1);
   b4 = V_diag2_pix(2);
   c4 = V_diag2_pix(3);
 
 
   A_kk = [a1*a2  b1*b2;
	        a3*a4  b3*b4];
   
   b_kk = -[c1*c2;c3*c4];
   

   A = [A;A_kk];
   b = [b;b_kk];
   
end;

% use all the vanishing points to estimate focal length:

f_init = sqrt(abs(1./(inv(A'*A)*A'*b))); % if using a two-focal model for initial guess

%f_init = sqrt(b'*(sum(A')') / (b'*b)) * ones(2,1); % if single focal length model is used


% Global calibration matrix (initial guess):
   	
KK = [f_init(1) 0 c_init(1);0 f_init(2) c_init(2); 0 0 1];
inv_KK = inv(KK);

	
% Computing of the extrinsic parameters (from the collineations)

for kk = 1:n_ima,
   
   eval(['Hkk = H_' num2str(kk) ';']);
   
   H2 = inv_KK*Hkk;
      
   sc = mean([norm(H2(:,1));norm(H2(:,2))]);
   
 	H2 = H2/sc;
   
  	omckk = rodrigues([H2(:,1:2) cross(H2(:,1),H2(:,2))]);
  	Tckk = H2(:,3);
   
  	eval(['omc_' num2str(kk) ' = omckk;']);
  	eval(['Tc_' num2str(kk) ' = Tckk;']);
   	
end;


      
% Initialisation of the parameters for global minimization:

init_param = [f_init;k_init];

for kk = 1:n_ima,   
   eval(['init_param = [init_param; omc_' num2str(kk) '; Tc_' num2str(kk) '];']);
end;

if exist('leastsq'),
   sss = ['[param,opt] = leastsq(''multi_error_oulu'',init_param,options,[],n_ima,c_init);'];
else
   sss = ['[param,opt] = leastsq2(''multi_error_oulu'',init_param,options,[],n_ima,c_init);'];
end;


fprintf(1,'\nOptimization not including the principal point...\n')

options = [1 1e-4 1e-4 1e-6  0 0 0 0 0 0 0 0 0 4000 0 1e-8 0.1 0];

eval(sss);

history  = [[init_param;c_init] [param;c_init]];

sol_no_center = [param;c_init];

init_param = sol_no_center;

fprintf(1,'\nOptimization including the principal point...\n')

eval(sss);

history = [history param];


sol_with_center = param;




%%% Extraction of the final intrinsic and extrinsic paramaters (in the no-center case):

solution = sol_no_center;
extract_parameters;

fprintf(1,'\n\nCalibration results without principal point estimation:\n\n');
fprintf(1,'Focal Length:     fc = [ %3.5f   %3.5f]\n',fc);
fprintf(1,'Principal point:  cc = [ %3.5f   %3.5f]\n',cc);
fprintf(1,'Distortion:       kc = [ %3.5f   %3.5f   %3.5f   %3.5f]\n',kc);   
fprintf(1,['Pixel error:      [click on ''sol. without center'']\n']); 




% Pick the solution with principal point
%%% NOTE: At that point, the user can choose which solution to pick: with or without
%%% principal point estimation. By default, we pick the solution with principal point.

solution = sol_with_center;



%%% Extraction of the final intrinsic and extrinsic paramaters:

extract_parameters;


fprintf(1,'\n\nCalibration results with principal point estimation:\n\n');
fprintf(1,'Focal Length:     fc = [ %3.5f   %3.5f]\n',fc);
fprintf(1,'Principal point:  cc = [ %3.5f   %3.5f]\n',cc);
fprintf(1,'Distortion:       kc = [ %3.5f   %3.5f   %3.5f   %3.5f]\n',kc);   


%%%%%%%%%%%%%%%%%%%% GRAPHICAL OUTPUT %%%%%%%%%%%%%%%%%%%%%%%%

graphout_calib;



fprintf(1,'Note: If the solution is not satisfactory, select solution without center estimation.\n\n');


%%%%%%%%%%%%%% Save all the Calibration results:

disp('Save calibration results under Calib_Results.mat');

string_save = 'save Calib_Results fc kc cc ex x y solution sol_with_center sol_no_center history wintx winty n_ima type_numbering N_slots small_calib_image first_num image_numbers format_image calib_name Hcal Wcal nx ny map dX_default dY_default KK inv_KK dX dY';

for kk = 1:n_ima,
   string_save = [string_save ' X_' num2str(kk) ' x_' num2str(kk) ' y_' num2str(kk) ' ex_' num2str(kk) ' omc_' num2str(kk) ' Tc_' num2str(kk) ' H_' num2str(kk) ' n_sq_x_' num2str(kk) ' n_sq_y_' num2str(kk)];
end;

eval(string_save);
