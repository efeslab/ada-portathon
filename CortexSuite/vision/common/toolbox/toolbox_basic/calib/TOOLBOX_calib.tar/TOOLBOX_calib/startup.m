% Main camera calibration toolbox:

calib_gui;

path(pwd,path);
