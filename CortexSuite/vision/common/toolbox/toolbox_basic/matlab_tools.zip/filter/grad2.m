function [gx,gy] = grad2(I,ratio)
%
%

gx = conv2(I,dgauss(1),'same');
gx = conv2(gx,gauss(ratio)','same');

gy = conv2(conv2(I,dgauss(1)','same'),gauss(ratio),'same');
