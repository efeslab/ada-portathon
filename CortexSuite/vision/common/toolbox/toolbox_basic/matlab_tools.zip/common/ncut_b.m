function [v,d] = ncut(A,nv)
%
%  [v,d] = ncut(A,nv)
%
%    computes 'nv' of the normalized cut vectors 'v' from
%    matrix 'A'
%

%
%  Jianbo Shi   
%

ds = sum(A);
ds = ones(size(ds))./sqrt(ds);

for j=1:size(A,1),
  A(j,:) = A(j,:).*ds;
end

for j=1:size(A,2);
  A(:,j) = A(:,j).*ds';
end

disp(sprintf('computing eig values'));
tic;[v,d] = eigs(A,nv);toc;

d = abs(diag(d));

for j=1:nv,
  v(:,j) = v(:,j).*ds';
end

