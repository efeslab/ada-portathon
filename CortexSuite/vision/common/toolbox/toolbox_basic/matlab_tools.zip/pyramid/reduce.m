function J = reduce(I)

J = gauss_lowpass(I);
J = J(1:2:size(J,1),1:2:size(J,2));
