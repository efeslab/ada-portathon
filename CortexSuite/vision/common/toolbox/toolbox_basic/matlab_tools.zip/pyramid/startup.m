home_dir = '/home/nef0/malik/jshi/jshi/matlab/';
path([home_dir,'toolbox/io'], path)
path([home_dir,'toolbox/filter'],path)
path(path,[home_dir,'vision/vision94/tracking/'])
clear home_dir