function ims(I,nr,nc)

im(reshape(I,nr,nc));