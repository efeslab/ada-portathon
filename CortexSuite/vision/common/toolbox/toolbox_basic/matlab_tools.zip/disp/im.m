function im(I)

imagesc(I);axis('image');drawnow;