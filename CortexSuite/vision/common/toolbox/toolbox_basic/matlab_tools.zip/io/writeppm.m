function writeppm(name,I1,I2,I3)

  [y,x] = size(I1);

  fid = fopen(name, 'w');
  fprintf(fid, 'P6\n%d %d\n255\n', x,y);

  I1 = reshape(I1',1,prod(size(I1)));
  I2 = reshape(I2',1,prod(size(I2)));
  I3 = reshape(I3',1,prod(size(I3)));
  
  fwrite(fid, [I1;I2;I3], 'uint8');
  fclose(fid);

