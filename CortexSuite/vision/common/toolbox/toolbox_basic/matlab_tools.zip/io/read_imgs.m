function Is = read_imgs(homedir,imgdir,prename,postname,digits,startid,endid,step_img)
%
% Is = read_imgs(homedir,imgdir,prename,postname,digits,startid,endid,step_img)
%



command = ['%s%s%s%.',num2str(digits),'d%s'];

fname = sprintf(command,homedir,imgdir,prename,startid,postname);
disp(fname);
I1 = readpgm(fname);

Is = zeros(size(I1,1),size(I1,2),1+floor((endid-startid)/step_img));
Is(:,:,1) = I1;
im_id = 1;
for j = startid+step_img:step_img:endid,
    command = ['%s%s%s%.',num2str(digits),'d%s'];
    fname = sprintf(command,homedir,imgdir,prename,j,postname);
    disp(fname);
    im_id = im_id+1;
    Is(:,:,im_id) = readpgm(fname);
end






